export class CreateRechargeApiDto {}
