export default {
    entity_operator: 'entity_operator',
    entity_provider: 'entity_provider',
    entity_commission: 'entity_commission',
    recharge_transaction: 'recharge_transaction',
}

export const ENTITY_OPERATOR_TYPE = ['MOBILE_RECHARGE']
export const RECHARGE_TRANSACTION_STATUS = ['PROCESSING', 'SUCCESSFUL', 'FAILED']
