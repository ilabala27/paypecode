export default {
    base_url: 'localhost',
    port: 3005,
    default_lang: "en"
}