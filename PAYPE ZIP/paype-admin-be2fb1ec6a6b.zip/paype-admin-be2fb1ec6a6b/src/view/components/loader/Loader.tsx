import React from 'react';

export function Loader() {
    return (
      <>
        
      </>
    );
}