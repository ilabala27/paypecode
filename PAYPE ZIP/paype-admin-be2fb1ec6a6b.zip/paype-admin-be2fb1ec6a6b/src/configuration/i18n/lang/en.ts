const english = {
    "Welcome": "English"
}

export default english