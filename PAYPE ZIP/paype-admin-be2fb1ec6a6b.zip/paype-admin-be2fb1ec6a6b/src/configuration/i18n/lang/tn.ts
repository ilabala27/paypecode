const tamil = {
    "Welcome": "Tamil"
}

export default tamil