export const color = {
    WHITE: "#fff",
}
