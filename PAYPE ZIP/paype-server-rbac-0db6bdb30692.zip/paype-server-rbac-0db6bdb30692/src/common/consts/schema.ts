export default {
    permission: 'permission',
    permission_group: 'permission_group',
    role: 'role'
}

export const PERMISSION_GROUP_EFFECT = ['Allow', 'Deny']