export default {
    base_url: 'localhost',
    port: 3001,
    default_lang: "en"
}