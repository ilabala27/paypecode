export default {
    base_url: 'localhost',
    port: 3002,
    default_lang: "en"
}