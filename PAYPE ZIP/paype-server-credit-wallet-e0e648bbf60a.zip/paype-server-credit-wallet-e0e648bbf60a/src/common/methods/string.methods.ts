export const toLowerCaseAndReplace = (string: string, replaceFrom: string, replaceTo: string) =>{
    return string.toLowerCase().replace(replaceFrom, replaceTo)
}