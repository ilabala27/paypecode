export default {
    base_url: 'localhost',
    port: 3000,
    default_lang: "en"
}