export const userDefaultQuery = `
        user._id = :id 
        OR user.user_id = :user_id 
`