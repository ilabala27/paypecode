export default {
    base_url: 'localhost',
    port: 3006,
    default_lang: "en"
}