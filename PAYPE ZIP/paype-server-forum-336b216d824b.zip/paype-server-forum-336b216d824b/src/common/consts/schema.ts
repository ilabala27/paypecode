export default {
    entity_story: 'entity_story',
}