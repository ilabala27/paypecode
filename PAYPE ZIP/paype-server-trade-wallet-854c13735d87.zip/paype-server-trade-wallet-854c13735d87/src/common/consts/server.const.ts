export default {
    base_url: 'localhost',
    port: 3003,
    default_lang: "en"
}