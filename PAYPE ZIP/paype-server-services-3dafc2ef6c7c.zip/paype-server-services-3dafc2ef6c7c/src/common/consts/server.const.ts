export default {
    base_url: 'localhost',
    port: 3004,
    default_lang: "en"
}