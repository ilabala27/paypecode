export default {
    category: 'category',
    services: 'services',
    user_favourite_service: 'user_favourite_service',
    onboarding_quota: 'onboarding_quota',
    onboarding_quota_transaction: 'onboarding_quota_transaction',
    recharge_transaction: 'recharge_transaction',
}


export const RECHARGE_TRANSACTION_STATUS = ['PROCESSING', 'SUCCESSFUL', 'FAILED']